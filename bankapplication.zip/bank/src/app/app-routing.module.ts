import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CarloanComponent } from './carloan/carloan.component';
import { ContactComponent } from './contact/contact.component';
import { CurrentComponent } from './current/current.component';
import { HomeComponent } from './home/home.component';
import { HomeloanComponent } from './homeloan/homeloan.component';
import { LoanComponent } from './loan/loan.component';
import { LoginComponent } from './login/login.component';
import { MedicalloanComponent } from './medicalloan/medicalloan.component';
import { ProfileComponent } from './profile/profile.component';
import { RegisterComponent } from './register/register.component';
import { SallaryComponent } from './sallary/sallary.component';
import { SavingComponent } from './saving/saving.component';
import { ServiceComponent } from './service/service.component';
import { VeiwdetailComponent } from './veiwdetail/veiwdetail.component';

const routes: Routes = [
  { path:'', component:HomeComponent},
{ path:'contact', component:ContactComponent},
{ path:'service', component:ServiceComponent},
{ path:'login', component:LoginComponent},
{ path:'register', component:RegisterComponent},
{ path:'loan', component:LoanComponent},
{ path:'carloan', component:CarloanComponent},
{ path:'homeloan', component:HomeloanComponent},
{ path:'medicalloan', component:MedicalloanComponent},
{ path:'about', component:AboutComponent},
{ path:'profile', component:ProfileComponent},
{ path:'veiwdetail/:id', component:VeiwdetailComponent},
{ path:'saving', component:SavingComponent},
{ path:'current', component:CurrentComponent},
{ path:'sallary', component:SallaryComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
