import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sallary',
  templateUrl: './sallary.component.html',
  styleUrls: ['./sallary.component.css']
})
export class SallaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
